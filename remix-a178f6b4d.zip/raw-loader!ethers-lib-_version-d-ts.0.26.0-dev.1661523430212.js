(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[85],{

/***/ 3291:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("export declare const version = \"ethers/5.5.1\";\n//# sourceMappingURL=_version.d.ts.map");

/***/ })

}]);
//# sourceMappingURL=raw-loader!ethers-lib-_version-d-ts.0.26.0-dev.1661523430212.js.map
//# sourceMappingURL=raw-loader!ethers-lib-_version-d-ts.0.26.0-dev.1661523430212.js.map